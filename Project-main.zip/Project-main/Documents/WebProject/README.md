# Web-Dev-Project
Our project work for the web development course. "ArtSpace" is a website with a photo gallery.
Team Members: Mukan Erkebulan, Moldamyrza Amina, Bakimov Shayakhmet.

